exports.validateId = (req, res, next) => {
    let id = req.params.id;
    if(id.match(/^[0-9a-fA-F]{24}$/)) {
        return next();
    }else{
        req.flash('error', 'Invalid connection id Entered! Please Check'); 
        //let err = new Error('Invalid story id');
        //error.status = 400;
        res.redirect('back');
        //return next(err);
    }
}