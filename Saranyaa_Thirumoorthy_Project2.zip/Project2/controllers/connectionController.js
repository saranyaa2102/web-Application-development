const model = require ('../models/connection');

exports.index = (req,res)=>{                 
     let stories = model.find();
     res.render('./connection/index',{stories});
 
 };
 
exports.new = (req,res)=>{
    res.render('./connection/new');
};

exports.create = (req,res)=>{

    let story = req.body;
    model.save(story);
    res.redirect('/connections');
};

exports.show = (req,res,next)=>{       
    let id = req.params.id        
    let story = model.findById(id);
    if (story){
        res.render('./connection/show',{story});
    }else{
        let err = new Error('No Connection with id '+id+' found. Please re-check the entered id !');
        err.status=404;
        next(err);
    }
};


exports.edit = (req,res,next)=>{                 
    let id = req.params.id        
    let story = model.findById(id);
    if (story){
        res.render('./connection/edit',{story});
    }else{
    let err = new Error('No connection with id '+id+' found to edit.');
    err.status=404;
    next(err);
    }
};

exports.update = (req,res,next)=> {
    let story = req.body;
    let id = req.params.id;
   if (model.updateById(id,story)){
    res.redirect('/connections/'+id);
    }else{
        let err = new Error('No connection with id '+id+' found to update. Please re-check the id !');
        err.status=404;
        next(err);
    }
};

exports.delete = (req,res,next)=> {
    let id = req.params.id;
    if (model.deleteById(id))
        res.redirect('/connections');
    else{
        let err = new Error('No Story with id '+id+' found to delete');
        err.status=404;
        next(err);
    }
};
