const { DateTime } = require("luxon");
const {v4: uuidv4, NIL} = require('uuid');

const stories = [
    {   
        category:"Books",
        id: '1',
        sub_title: 'Meet your Favourite Authors Every Week',
        title: 'Meet your favourite authors',
        details: 'When words in the book spoke so much to you, how about meeting the person behind those words. ?! Exited, aren\'t you ? Do visit the venue to meet the author.',
        start_date: 'March 21,2021',
        end_date: 'March 22, 2021',
        start_time:'10:30 am',
        end_time: '12:30 pm',
        host_name:'Student Activity Center - UNCC',
        image: '/images/author.jpg',
        location: 'Dale F. Halton Area, UNC Charlotte',
        image_tag:'author'
    },
    {
        category:"Books",
        id: '2',
        sub_title: 'The Publisher\'s Meet',
        title: 'Want to publish your book?',
        details: 'Are you an avid writer ? Willing to publicize your work ? This event is just for you. The Mcmillan Group is organizing a fair where the famous publishers collaborate and provide great deals. Vist and book a deal to publish your work.',
        start_date: 'March 27,2021',
        end_date: 'March 28, 2021',
        start_time:'10:30 am',
        end_time: '04:00 pm',
        host_name:'Macmillan Groups',
        image: '/images/publishers.jpg',
        location: 'Dale F. Halton Area, UNC Charlotte',
        image_tag:'publishers'
    }, 
    {
        category:"Books",
        id: '3',
        sub_title: 'Sell Used Books / Share Books For a while',
        title: 'Share/Sell a book',
        details: 'Want to sell out pile of your old but meaningful books? Want to share book to someone who is looking for it? Explore the options by visiting the event.',
        start_date: 'April 4,2021',
        end_date: 'April 5, 2021',
        start_time:'09:30 am',
        end_time: '04:00 pm',
        host_name:'Book Scouter',
        image: '/images/sharebook.jpg',
        location: '72 Noble St, Brooklyn, NY 11222',
        image_tag:'sellandShareBooks'
    
    },
    {
    category:"Books",
    id: '4',
    sub_title: 'Queen City Book Fair',
    title: 'Book Fair',
    details: 'We cordially invite everyone to a visit our book fair comprising book of various genre. We offer greate offers.Do visit the fair & enjoy!',
    start_date: 'April 15,2021',
    end_date: 'April 19, 2021',
    start_time:'10:30 am',
    end_time: '06:00 pm',
    host_name:'Quish Dynae & Shmel Carter',
    image: '/images/bookFair.jpg',
    location: 'The Carole Hoefener Center, 615 E 6th St, Charlotte, NC',
    image_tag:'bookFair'
  },
  {
    category:"Music",
    id: '5',
    sub_title: 'Music Concert From your favourite band',
    title: 'Music Concert',
    details: 'Taco Bell\'s Feed the Beat has helped more than 1,700 artists/bands. This concert presents diversed music flavours such as western musics, carnatic musics, hindustani, hip-hops, rap songs. Book your visit and cherish the music taste. NOTE: Covid-19 prevention guidelines applied.',
    start_date: 'April 29,2021',
    end_date: 'April 30, 2021',
    start_time:'10:30 am',
    end_time: '06:00 pm',
    host_name:'Taco Bell\'s, Feed The Beat',
    image: '/images/concert.jpg',
    location: '1 State Farm Dr, Atlanta, GA 30303',
    image_tag:'concert'
   },
   {
    category:"Music",
    id: '6',
    sub_title: 'Music Festival',
    title: 'Art & Music Festival',
    details: 'This music festival offers best music concerts, sale for musical instruments for best deals, Meet up with great musicians, on-spot singing & win opportunity for singing with best music directors. NOTE: Covid-19 prevention guidelines applied.',
    start_date: 'April 29,2021',
    end_date: 'April 30, 2021',
    start_time:'10:30 am',
    end_time: '06:00 pm',
    host_name:'Anhueser-Busch',
    image: '/images/music_Festival.jpg',
    location: 'Randall\'s Island, New York City, NY',
    image_tag:'musicFestival'
   },
   {
    category:"Music",
    id: '7',
    sub_title: 'Jazz Concert from the natives',
    title: 'Jazz Concert',
    details: 'Want to feel and taste the Jazz ! This concert is for you. NOTE: Covid-19 prevention guidelines applied.',
    start_date: 'April 29,2021',
    end_date: 'April 30, 2021',
    start_time:'10:30 am',
    end_time: '06:00 pm',
    host_name:'Pepsico',
    image: '/images/jazz_festival.jpg',
    location: 'The Hall, 520 South Michigan Avenue • Chicago, IL - 60605',
    image_tag:'jazzFestival',
   },
   {
    category:"Music",
    id: '8',
    sub_title: 'Music Conference with the Directors',
    title: 'Music Conference',
    details: 'Meet the top musicians and get a chance to interact with them. NOTE: Covid-19 prevention guidelines applied.',
    start_date: 'April 8,2021',
    end_date: 'April 9, 2021',
    start_time:'01:00 pm',
    end_time: '06:00 pm',
    host_name:'Harman',
    image: '/images/conference.jpg',
    location: 'Concord, 1480 Concord Pkwy N, Concord, NC 28025',
    image_tag:'conference'
   },
   {
    category:"Fitness",
    id: '9',
    sub_title: 'Dietry & Fitness Camp',
    title: 'Fitness & Dietry Camp',
    details: 'Do you feel like a couch potato in the silicon Valley? No worries. You are sailing on the same boat as many other potatos. Visit the camp and get to know about the nutrition and healty diets to become fit.',
    start_date: 'April 18,2021',
    end_date: 'April 19, 2021',
    start_time:'10:00 am',
    end_time: '01:00 pm',
    host_name:'Equinox Fitness Center',
    image: '/images/fitness_Camp.jpg',
    location: 'Los Angeles Convention Center, 1201 South Figueroa Street LA, California 90015',
    image_tag:'fitnessCamp'
   },
   {
    category:"Fitness",
    id: '10',
    sub_title: 'Join The Yoga Crowd',
    title: 'Yoga For All',
    details: 'Yoga gives you good health, mind and focus. Its time to take care of yourself. Please join the event & get benefited.',
    start_date: 'May 01,2021',
    end_date: 'May 02, 2021',
    start_time:'07:00 am',
    end_time: '10:00 am',
    host_name:'Isha Foundation',
    image: '/images/yoga.jpg',
    location: 'Asbury Park Convention Hall, 1300 Ocean Ave, Asbury Park, NJ 07712',
    image_tag:'yoga'
    
   },
   {
    category:"Fitness",
    id: '11',
    sub_title: 'zumba class for Zeal ',
    title: 'Zumba Zeal',
    details: 'Want an power packed energetic day?! What are you waiting for, Jump into the zumba class & enjoy.',
    start_date: 'May 05,2021',
    end_date: 'May 06, 2021',
    start_time:'06:00 am',
    end_time: '08:00 am',
    host_name:'Cult Fit',
    image: '/images/zumba.jpg',
    location: 'Washington Convention Center, 705 Pike St, Seattle, WA 98101',
    image_tag:'zumba'
  },
  {
    category:"Fitness",
    id: '12',
    sub_title: 'Gym Offer',
    title: 'Equipment & Membership Offer',
    details: 'Are you a fitness freak ? Want gym at home? Want to get early offers on your gym membership? Visit the event & get benefited from various fitness companies.',
    start_date: 'May 11,2021',
    end_date: 'May 12, 2021',
    start_time:'10:00 am',
    end_time: '02:00 pm',
    host_name:'The World Fitness Center',
    image: '/images/gym_offer.jpg',
    location: 'San Diego Convention Center,111 W Harbor Dr,San Diego,CA 92101',
    image_tag:'gymOffer'
  },
  {
    category:"Food",
    id: '13',
    sub_title: 'The Chef\'s Collab for tastes Collabs',
    title: 'The Chef\'s Meet',
    details: 'This event is a meetup of The Chefs from diversed star hotel groups, small scale restaurants & your street food makers. They will share the secret recepies of their favourite dishes. What are you waiting for? Visit & know about the secret recepie.',
    start_date: 'April 21,2021',
    end_date: 'April 21, 2021',
    start_time:'10:00 am',
    end_time: '05:00 pm',
    host_name:'Star World',
    image: '/images/ChefMeet.jpg',
    location: 'The Orland, 14500 S La Grange Rd Orland Park, IL 60462',
    image_tag:'fitnessCamp'
    
  },
  {
    category:"Food",
    id: '14',
    sub_title: 'Food Festival is here for you',
    title: 'Food Festival',
    details: 'From home made food to international cuisine, this food festival is hosted to serve the visitors with multi national cuisine. What are you waiting for? Grab a ticket & enter the food counters!',
    start_date: 'April 30,2021',
    end_date: 'April 30, 2021',
    start_time:'10:00 am',
    end_time: '05:00 pm',
    host_name:'Nestle',
    image: '/images/FoodFestival.JPG',
    location: 'The Convention Hall, 415 Summer St, Boston, MA 02210',
    image_tag:'foodFestivals'
    
  },
  {
    category:"Food",
    id: '15',
    sub_title: 'Pan-Plate-Heart',
    title: 'Cooking Compatition',
    details: 'Are you a chef @ home ? Become chef for everybody\'s home by showcasing your cooking skills by participating in the compatition. Register in the website of Star World.',
    start_date: 'May 10,2021',
    end_date: 'May 11, 2021',
    start_time:'10:00 am',
    end_time: '05:00 pm',
    host_name:'Star World',
    image: '/images/compatition.jpg',
    location: 'The Orland, 14500 S La Grange Rd Orland Park, IL 60462',
    image_tag:'cookingCompatition'
   }
];

exports.find = function(){
    return stories;
};

exports.findById = function(id){
    return stories.find(story=> story.id === id);
};

exports.save = function (story) {
    story.id = uuidv4();
    stories.push(story);
}

exports.updateById=function(id,newStory){
    let story = stories.find(story=> story.id === id);
    if(story){
    story.title = newStory.title; 
    story.sub_title= newStory.sub_title;
    story.details=newStory.details;
    story.start_date=newStory.start_date;
    story.end_date=newStory.end_date;
    story.start_time=newStory.start_time;
    story.end_time=newStory.end_time;
    story.host_name=newStory.host_name;
    story.location=newStory.location;
    return true;
    }else{
        return false;
    }
}

exports.deleteById = function(id){
    let index = stories.findIndex(story => story.id === id);
    if (index != -1){
        stories.splice(index,1);
        return true;
    }else{
        return false;
    }
}