const model = require ('../models/connection');

exports.index = (req,res, next)=>{
     model.find()
     .then(connections=>res.render('./connection/index', {connections}))
     .catch(err=>next(err));
 };
 
exports.new = (req,res)=>{
    
    res.render('./connection/new');
};

exports.create = (req,res,next)=>{
    let story = new model(req.body);//invoke the constructor 
    story.author = req.session.user;
        story.save()//insert the document to database
        .then(story=> {
            req.flash('success', 'Event successfully Created!');
            res.redirect('/connections');
        })
        .catch(err=>{
            if(err.name === 'ValidationError') {
                err.status = 400;
                //res.redirect('back'+id);
            }
            next(err);
        
        });
};

exports.show = (req,res,next)=>{       
    let id = req.params.id;
    
    model.findById(id).populate('author', 'firstName lastName')
    .then(story=>{
        if(story){
            const rsvpYes = story.rsvp.filter(({rsvpResponse}) => rsvpResponse == 'yes');
            return res.render('./connection/show',{story ,rsvpYes});
        }
    })
    .catch(err => next(err));
};

exports.edit = (req,res,next)=>{                 
    let id = req.params.id;//connection id
    //console.log(id);
    model.findById(id)
    .then(story => {
            res.render('./connection/edit',{story});
    })
    .catch(err => next(err));
};


exports.update = (req,res,next)=> {
    let story = req.body;
    let id = req.params.id;
    model.findByIdAndUpdate(id, story,{useFindAndModify: false, runValidators: true})
    .then(story => {
            req.flash('success', 'Event successfully updated!');
            res.redirect('/connections/'+id);
    })
    .catch(err=>next(err));
};

exports.delete = (req,res,next)=> {
    let id = req.params.id;
    
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(story=>{
            req.flash('success', 'Event successfully deleted!');
            res.redirect('/connections');
    })
    .catch(err => next(err));
};



exports.rsvp = (req, res, next) => {
    let id = req.params.id;
    let currentRsvpResonpse = req.query.rsvp.toLowerCase();
    //console.log(currentRsvpResonpse);
    let userId = req.session.user;

    model.findById(id)
    .then(story=> {
        if(story){
            console.log(story);
            if(userId == story.author){
                req.flash('error','RSVP to self created event is not allowed');
                let err = new Error('Unauthorized to access the resources');
                err.status = 401;
                return next(err);
                //return res.redirect('back');            
            }else if (currentRsvpResonpse == ''){
                req.flash('error','RSVP cannot be empty. Value is required!')
                return res.redirect('back');
            
            }else if (currentRsvpResonpse != 'yes'  &&  currentRsvpResonpse != 'no' && currentRsvpResonpse != 'maybe'){
                    req.flash('error','RSVP values can only be yes,no or maybe');
                    return res.redirect('back');
            }else{
              
                const oldRsvpResponses = story.rsvp.filter(({user}) => user == userId);
                if(oldRsvpResponses.length != 0) {
                    const oldRsvpResponseValues = oldRsvpResponses[0];
                    oldRsvpResponseValues.rsvpResponse = currentRsvpResonpse;
                    }else {
                    var rsvpElement = {
                        user : userId,
                        rsvpResponse : currentRsvpResonpse
                    };
                    story.rsvp.push(rsvpElement);
                }
                model.findByIdAndUpdate(id, story, {useFindAndModify: false, runValidators: true})
                .then(story=> {
                    req.flash('success', 'RSVP successfully recorded for the event!');  
                    res.redirect('/users/profile');
                })
            }
        }    
    })
    .catch( err => next(err));
};

exports.deleteRsvp = (req, res, next) => {
    let id = req.params.id;
    model.findById(id)
    .then(story=> {
        if(story) {

            const rsvpToDelete = story.rsvp.filter(({user}) => user == req.session.user);
            let index = story.rsvp.indexOf(rsvpToDelete);
            story.rsvp.splice(index,1);

            model.findByIdAndUpdate(id, story, {useFindAndModify: false, runValidators: true})
            .then(story=> {
                if(story){
                    req.flash('success', 'RSVP records deleted successfully for the event!');  
                    //res.redirect('/connections/'+id);
                    res.redirect('/users/profile');
                }
            })
        } 
    })
    .catch( err => next(err));
};
