const express = require('express');
const controller = require('../controllers/connectionController');
const {isLoggedIn, isAuthor} = require('../middlewares/auth');
const {validateId} = require('../middlewares/validator');
const {body} = require('express-validator');
const {validateConnection, validateResult} = require('../middlewares/validator');

const router = express.Router();

router.get('/',controller.index); 

router.get('/new', isLoggedIn, controller.new); 

router.post('/', isLoggedIn, validateConnection, validateResult, controller.create);

router.get('/:id', validateId, controller.show);

router.get('/:id/edit', validateId, isLoggedIn, isAuthor, controller.edit);

router.post('/:id', isLoggedIn, validateId, controller.rsvp);

router.delete('/:id/rsvp', validateId, isLoggedIn, controller.deleteRsvp);

router.put('/:id', validateId, isLoggedIn, isAuthor, validateConnection, validateResult, controller.update);

router.delete('/:id', validateId, isLoggedIn, isAuthor, controller.delete);

module.exports = router;

