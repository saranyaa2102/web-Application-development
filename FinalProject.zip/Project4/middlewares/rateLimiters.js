const rateLimit = require("express-rate-Limit");

exports.logInLimiter = rateLimit({
    windowMS: 60 * 1000, //one minute
    max : 5,
    //message: 'Too Many Login requests. Try again later'
    handler: (req,res, next) => {
        let err = new Error('Too Many log in requests. Please try again after some time');
        err.status = 429;
        return next(err);
    }
});
